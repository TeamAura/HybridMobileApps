var todo = (function () {
    console.log("test");
}());

todo;